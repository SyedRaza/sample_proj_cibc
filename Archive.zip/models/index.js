module.exports =  (keystone) => {
    for (const aFile of require('fs').readdirSync(__dirname, { withFileTypes: true }).filter(ent => ent.isFile() && ent.name !== 'index.js')) {
        const [ name, suffix ] = aFile.name.split('.');
        nameB = name.charAt(0).toUpperCase() + name.substring(1, name.length);
        keystone.createList( nameB, require(`./${aFile.name}`));
    }
}

